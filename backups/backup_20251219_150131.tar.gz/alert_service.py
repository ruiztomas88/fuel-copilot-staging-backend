"""
Alert Service - Multi-channel notifications for Fuel Copilot

Supports:
- SMS via Twilio
- WhatsApp via Twilio
- Email via SMTP
- Webhook for custom integrations

Author: Fuel Copilot Team
Version: v3.4.1
Date: November 25, 2025

Setup:
1. Get Twilio credentials: https://www.twilio.com/console
2. Add to .env:
   TWILIO_ACCOUNT_SID=your_sid
   TWILIO_AUTH_TOKEN=your_token
   TWILIO_FROM_NUMBER=+1234567890
   TWILIO_TO_NUMBERS=+1234567890,+0987654321

3. For Email alerts:
   SMTP_SERVER=smtp-mail.outlook.com
   SMTP_PORT=587
   SMTP_USER=your_email@domain.com
   SMTP_PASS=your_password
   ALERT_EMAIL_TO=recipient@domain.com

⏰ TIMEZONE:
- Uses timezone_utils for consistent UTC handling
"""

import os
import logging
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import List, Optional, Dict, Any
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from dotenv import load_dotenv

from timezone_utils import utc_now

# Load environment variables
load_dotenv()

logger = logging.getLogger(__name__)


class AlertPriority(Enum):
    """Alert priority levels"""

    LOW = "low"  # Informational
    MEDIUM = "medium"  # Needs attention soon
    HIGH = "high"  # Needs attention now
    CRITICAL = "critical"  # Emergency - possible theft


class AlertType(Enum):
    """Types of alerts"""

    REFUEL = "refuel"
    THEFT_SUSPECTED = "theft_suspected"
    THEFT_CONFIRMED = "theft_confirmed"  # 🆕 Drop that didn't recover
    SENSOR_ISSUE = "sensor_issue"  # 🆕 Drop that recovered = sensor glitch
    DRIFT_WARNING = "drift_warning"
    SENSOR_OFFLINE = "sensor_offline"
    LOW_FUEL = "low_fuel"
    EFFICIENCY_DROP = "efficiency_drop"
    MAINTENANCE_DUE = "maintenance_due"
    DTC_ALERT = "dtc_alert"  # 🆕 v5.7.3: Diagnostic trouble code
    VOLTAGE_ALERT = "voltage_alert"  # 🆕 v5.7.3: Battery/alternator issue
    IDLE_DEVIATION = "idle_deviation"  # 🆕 v5.7.6: Idle calculation vs ECU mismatch
    GPS_QUALITY = "gps_quality"  # 🆕 v5.7.6: Poor GPS signal
    MAINTENANCE_PREDICTION = (
        "maintenance_prediction"  # 🆕 v5.7.9: Days-to-failure alert
    )


@dataclass
class Alert:
    """Alert data structure"""

    alert_type: AlertType
    priority: AlertPriority
    truck_id: str
    message: str
    details: Optional[Dict[str, Any]] = None
    timestamp: datetime = None

    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = utc_now()


# ═══════════════════════════════════════════════════════════════════════════════
# 🆕 FUEL EVENT CLASSIFIER v1.0
# ═══════════════════════════════════════════════════════════════════════════════
# Differentiates between THEFT, SENSOR_ISSUE, and REFUEL events
# by tracking fuel drops and monitoring for recovery patterns.
#
# Logic:
# - When fuel drops significantly, we buffer it as "pending_drop"
# - We wait RECOVERY_WINDOW_MINUTES to see if fuel recovers
# - If fuel recovers to within RECOVERY_TOLERANCE_PCT → SENSOR_ISSUE
# - If fuel stays low → THEFT_CONFIRMED
# - If fuel rises by REFUEL_THRESHOLD → REFUEL
# ═══════════════════════════════════════════════════════════════════════════════


@dataclass
class PendingFuelDrop:
    """Tracks a fuel drop waiting for classification"""

    truck_id: str
    drop_timestamp: datetime
    fuel_before: float  # Fuel level before drop (%)
    fuel_after: float  # Fuel level after drop (%)
    drop_pct: float  # Percentage dropped
    drop_gal: float  # Gallons dropped
    location: Optional[str] = None
    truck_status: str = "UNKNOWN"  # MOVING, STOPPED, IDLE

    def age_minutes(self) -> float:
        """Minutes since this drop was detected"""
        return (utc_now() - self.drop_timestamp).total_seconds() / 60


class FuelEventClassifier:
    """
    🆕 v1.0 - Intelligent fuel event classification

    Differentiates between:
    - THEFT: Fuel drop that doesn't recover
    - SENSOR_ISSUE: Fuel drop that recovers quickly (sensor glitch)
    - REFUEL: Fuel increase

    Configuration (from .env):
    - RECOVERY_WINDOW_MINUTES: Time to wait for recovery (default: 10)
    - RECOVERY_TOLERANCE_PCT: How close recovery must be (default: 5%)
    - SENSOR_VOLATILITY_THRESHOLD: Max std deviation for "noisy sensor" (default: 8)
    """

    def __init__(self):
        # Configuration from environment
        self.recovery_window_minutes = int(os.getenv("RECOVERY_WINDOW_MINUTES", "10"))
        self.recovery_tolerance_pct = float(os.getenv("RECOVERY_TOLERANCE_PCT", "5.0"))
        self.drop_threshold_pct = float(os.getenv("DROP_THRESHOLD_PCT", "10.0"))
        self.refuel_threshold_pct = float(os.getenv("REFUEL_THRESHOLD_PCT", "8.0"))
        self.sensor_volatility_threshold = float(
            os.getenv("SENSOR_VOLATILITY_THRESHOLD", "8.0")
        )

        # Track pending drops awaiting classification
        self._pending_drops: Dict[str, PendingFuelDrop] = {}

        # Track recent fuel readings for volatility analysis
        self._fuel_history: Dict[str, List[tuple]] = (
            {}
        )  # truck_id -> [(timestamp, fuel_pct), ...]
        self._max_history_per_truck = 20

        logger.info(f"🔬 FuelEventClassifier initialized:")
        logger.info(f"   Recovery window: {self.recovery_window_minutes} min")
        logger.info(f"   Recovery tolerance: {self.recovery_tolerance_pct}%")
        logger.info(f"   Drop threshold: {self.drop_threshold_pct}%")
        logger.info(f"   Volatility threshold: {self.sensor_volatility_threshold}")

    def add_fuel_reading(
        self, truck_id: str, fuel_pct: float, timestamp: datetime = None
    ):
        """Record a fuel reading for volatility analysis"""
        ts = timestamp or utc_now()

        if truck_id not in self._fuel_history:
            self._fuel_history[truck_id] = []

        self._fuel_history[truck_id].append((ts, fuel_pct))

        # Keep only recent readings
        if len(self._fuel_history[truck_id]) > self._max_history_per_truck:
            self._fuel_history[truck_id] = self._fuel_history[truck_id][
                -self._max_history_per_truck :
            ]

    def get_sensor_volatility(self, truck_id: str) -> float:
        """
        Calculate sensor volatility (standard deviation) for a truck.
        High volatility = unreliable sensor readings.
        """
        history = self._fuel_history.get(truck_id, [])
        if len(history) < 5:
            return 0.0

        values = [v for _, v in history]
        mean = sum(values) / len(values)
        variance = sum((v - mean) ** 2 for v in values) / len(values)
        return variance**0.5

    def register_fuel_drop(
        self,
        truck_id: str,
        fuel_before: float,
        fuel_after: float,
        tank_capacity_gal: float = 200.0,
        location: str = None,
        truck_status: str = "UNKNOWN",
    ) -> Optional[str]:
        """
        Register a detected fuel drop. Returns immediate classification if possible,
        or None if we need to wait for recovery window.

        Returns:
            - "IMMEDIATE_THEFT" if conditions are extreme
            - None if we need to wait for recovery check
        """
        drop_pct = fuel_before - fuel_after
        drop_gal = drop_pct * tank_capacity_gal / 100

        # Check sensor volatility first
        volatility = self.get_sensor_volatility(truck_id)
        if volatility > self.sensor_volatility_threshold:
            logger.warning(
                f"🔧 {truck_id}: High sensor volatility ({volatility:.1f}). "
                f"Drop of {drop_pct:.1f}% likely sensor issue."
            )
            # Don't buffer - classify as sensor issue immediately if volatility is very high
            if volatility > self.sensor_volatility_threshold * 1.5:
                return "SENSOR_VOLATILE"

        # Buffer this drop for recovery monitoring
        pending = PendingFuelDrop(
            truck_id=truck_id,
            drop_timestamp=utc_now(),
            fuel_before=fuel_before,
            fuel_after=fuel_after,
            drop_pct=drop_pct,
            drop_gal=drop_gal,
            location=location,
            truck_status=truck_status,
        )
        self._pending_drops[truck_id] = pending

        logger.info(
            f"⏳ {truck_id}: Fuel drop of {drop_pct:.1f}% ({drop_gal:.1f} gal) buffered. "
            f"Waiting {self.recovery_window_minutes} min for recovery check."
        )

        # Check for extreme theft (very large drop while stopped)
        if drop_pct > 30 and truck_status == "STOPPED":
            logger.warning(
                f"🚨 {truck_id}: EXTREME drop ({drop_pct:.1f}%) while stopped - likely theft"
            )
            return "IMMEDIATE_THEFT"

        return None

    def check_recovery(
        self,
        truck_id: str,
        current_fuel_pct: float,
    ) -> Optional[Dict]:
        """
        Check if a pending fuel drop has recovered (sensor issue) or stayed low (theft).

        Returns:
            Dict with classification result, or None if no pending drop or still waiting
        """
        pending = self._pending_drops.get(truck_id)
        if not pending:
            return None

        age_minutes = pending.age_minutes()

        # Not enough time has passed yet
        if age_minutes < self.recovery_window_minutes:
            return None

        # Check if fuel recovered
        recovery_pct = current_fuel_pct - pending.fuel_after
        recovered_to = current_fuel_pct
        original_level = pending.fuel_before

        # Calculate how close to original level
        recovery_gap = abs(original_level - recovered_to)

        # Remove from pending
        del self._pending_drops[truck_id]

        # Classification logic
        if recovery_gap <= self.recovery_tolerance_pct:
            # Fuel recovered to near-original level = SENSOR ISSUE
            classification = "SENSOR_ISSUE"
            logger.info(
                f"🔧 {truck_id}: Fuel RECOVERED from {pending.fuel_after:.1f}% to {recovered_to:.1f}% "
                f"(original: {original_level:.1f}%). Classification: SENSOR_ISSUE"
            )
        elif recovery_pct > self.refuel_threshold_pct:
            # Fuel went UP significantly = REFUEL (not theft)
            classification = "REFUEL_AFTER_DROP"
            logger.info(
                f"⛽ {truck_id}: Fuel INCREASED from {pending.fuel_after:.1f}% to {recovered_to:.1f}%. "
                f"Classification: REFUEL (not theft)"
            )
        else:
            # Fuel stayed low = CONFIRMED THEFT
            classification = "THEFT_CONFIRMED"
            logger.warning(
                f"🚨 {truck_id}: Fuel stayed at {recovered_to:.1f}% after {age_minutes:.0f} min. "
                f"Original: {original_level:.1f}%. Classification: THEFT_CONFIRMED"
            )

        return {
            "classification": classification,
            "truck_id": truck_id,
            "original_fuel_pct": original_level,
            "drop_fuel_pct": pending.fuel_after,
            "current_fuel_pct": recovered_to,
            "drop_pct": pending.drop_pct,
            "drop_gal": pending.drop_gal,
            "recovery_pct": recovery_pct,
            "time_waited_minutes": age_minutes,
            "location": pending.location,
            "truck_status": pending.truck_status,
        }

    def process_fuel_reading(
        self,
        truck_id: str,
        last_fuel_pct: float,
        current_fuel_pct: float,
        tank_capacity_gal: float = 200.0,
        location: str = None,
        truck_status: str = "UNKNOWN",
    ) -> Optional[Dict]:
        """
        Main entry point: Process a new fuel reading and return any classification.

        This method:
        1. Records the reading for volatility tracking
        2. Checks for pending drop recovery
        3. Detects new drops and buffers them
        4. Detects refuels

        Returns:
            Dict with event classification, or None if no event
        """
        # Track reading for volatility
        self.add_fuel_reading(truck_id, current_fuel_pct)

        # First, check if any pending drop has recovered/expired
        recovery_result = self.check_recovery(truck_id, current_fuel_pct)
        if recovery_result:
            return recovery_result

        # Check for refuel (significant increase)
        increase_pct = current_fuel_pct - last_fuel_pct
        if increase_pct >= self.refuel_threshold_pct:
            increase_gal = increase_pct * tank_capacity_gal / 100
            return {
                "classification": "REFUEL",
                "truck_id": truck_id,
                "increase_pct": increase_pct,
                "increase_gal": increase_gal,
                "from_pct": last_fuel_pct,
                "to_pct": current_fuel_pct,
                "location": location,
            }

        # Check for significant drop
        drop_pct = last_fuel_pct - current_fuel_pct
        if drop_pct >= self.drop_threshold_pct:
            immediate = self.register_fuel_drop(
                truck_id=truck_id,
                fuel_before=last_fuel_pct,
                fuel_after=current_fuel_pct,
                tank_capacity_gal=tank_capacity_gal,
                location=location,
                truck_status=truck_status,
            )

            if immediate == "IMMEDIATE_THEFT":
                return {
                    "classification": "THEFT_SUSPECTED",
                    "truck_id": truck_id,
                    "drop_pct": drop_pct,
                    "drop_gal": drop_pct * tank_capacity_gal / 100,
                    "from_pct": last_fuel_pct,
                    "to_pct": current_fuel_pct,
                    "location": location,
                    "truck_status": truck_status,
                    "reason": "Extreme drop while stopped",
                }
            elif immediate == "SENSOR_VOLATILE":
                return {
                    "classification": "SENSOR_ISSUE",
                    "truck_id": truck_id,
                    "drop_pct": drop_pct,
                    "from_pct": last_fuel_pct,
                    "to_pct": current_fuel_pct,
                    "reason": "High sensor volatility detected",
                    "volatility": self.get_sensor_volatility(truck_id),
                }

            # Drop is buffered, waiting for recovery check
            return {
                "classification": "PENDING_VERIFICATION",
                "truck_id": truck_id,
                "drop_pct": drop_pct,
                "message": f"Drop detected, monitoring for {self.recovery_window_minutes} min",
            }

        return None

    def get_pending_drops(self) -> List[PendingFuelDrop]:
        """Get all pending drops awaiting classification"""
        return list(self._pending_drops.values())

    def force_classify_pending(
        self, truck_id: str, current_fuel_pct: float
    ) -> Optional[Dict]:
        """Force classification of a pending drop (for manual intervention)"""
        pending = self._pending_drops.get(truck_id)
        if not pending:
            return None

        # Temporarily set a very long window, then check recovery
        original_window = self.recovery_window_minutes
        self.recovery_window_minutes = 0
        result = self.check_recovery(truck_id, current_fuel_pct)
        self.recovery_window_minutes = original_window
        return result


# Global classifier instance
_fuel_classifier: Optional[FuelEventClassifier] = None


def get_fuel_classifier() -> FuelEventClassifier:
    """Get or create the global FuelEventClassifier instance"""
    global _fuel_classifier
    if _fuel_classifier is None:
        _fuel_classifier = FuelEventClassifier()
    return _fuel_classifier


@dataclass
class TwilioConfig:
    """Twilio configuration from environment"""

    account_sid: str = None
    auth_token: str = None
    from_number: str = None
    to_numbers: List[str] = None
    whatsapp_from: str = None

    def __post_init__(self):
        self.account_sid = os.getenv("TWILIO_ACCOUNT_SID", "")
        self.auth_token = os.getenv("TWILIO_AUTH_TOKEN", "")
        self.from_number = os.getenv("TWILIO_FROM_NUMBER", "")
        to_numbers_str = os.getenv("TWILIO_TO_NUMBERS", "")
        self.to_numbers = [n.strip() for n in to_numbers_str.split(",") if n.strip()]
        self.whatsapp_from = os.getenv("TWILIO_WHATSAPP_FROM", "")

    def is_configured(self) -> bool:
        """Check if Twilio is properly configured"""
        return bool(self.account_sid and self.auth_token and self.from_number)


class TwilioAlertService:
    """Send alerts via Twilio SMS and WhatsApp"""

    def __init__(self, config: TwilioConfig = None):
        self.config = config or TwilioConfig()
        self._client = None
        self._initialized = False

    def _initialize_client(self):
        """Lazy initialization of Twilio client"""
        if self._initialized:
            return self._client is not None

        if not self.config.is_configured():
            logger.warning("⚠️ Twilio not configured. SMS alerts disabled.")
            logger.info(
                "   Set TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_FROM_NUMBER in .env"
            )
            self._initialized = True
            return False

        try:
            from twilio.rest import Client

            self._client = Client(self.config.account_sid, self.config.auth_token)
            logger.info("✅ Twilio client initialized successfully")
            self._initialized = True
            return True
        except ImportError:
            logger.warning("⚠️ Twilio library not installed. Run: pip install twilio")
            self._initialized = True
            return False
        except Exception as e:
            logger.error(f"❌ Failed to initialize Twilio: {e}")
            self._initialized = True
            return False

    def send_sms(self, to_number: str, message: str) -> bool:
        """
        Send SMS to a specific number

        Args:
            to_number: Recipient phone number (E.164 format: +1234567890)
            message: Message content (max 1600 chars for concatenated SMS)

        Returns:
            True if sent successfully
        """
        if not self._initialize_client():
            return False

        try:
            # Truncate message if too long
            if len(message) > 1600:
                message = message[:1597] + "..."

            result = self._client.messages.create(
                body=message, from_=self.config.from_number, to=to_number
            )
            logger.info(f"📱 SMS sent to {to_number}: {result.sid}")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to send SMS to {to_number}: {e}")
            return False

    def send_whatsapp(self, to_number: str, message: str) -> bool:
        """
        Send WhatsApp message

        Args:
            to_number: Recipient phone number (E.164 format)
            message: Message content

        Returns:
            True if sent successfully
        """
        if not self._initialize_client():
            return False

        if not self.config.whatsapp_from:
            logger.warning("WhatsApp not configured (TWILIO_WHATSAPP_FROM missing)")
            return False

        try:
            result = self._client.messages.create(
                body=message,
                from_=f"whatsapp:{self.config.whatsapp_from}",
                to=f"whatsapp:{to_number}",
            )
            logger.info(f"📲 WhatsApp sent to {to_number}: {result.sid}")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to send WhatsApp to {to_number}: {e}")
            return False

    def broadcast_sms(self, message: str, numbers: List[str] = None) -> Dict[str, bool]:
        """
        Send SMS to multiple numbers

        Args:
            message: Message content
            numbers: List of phone numbers (uses config.to_numbers if None)

        Returns:
            Dict mapping number to success status
        """
        numbers = numbers or self.config.to_numbers
        if not numbers:
            logger.warning("No recipient numbers configured")
            return {}

        results = {}
        for number in numbers:
            results[number] = self.send_sms(number, message)

        success_count = sum(results.values())
        logger.info(f"📱 Broadcast complete: {success_count}/{len(numbers)} sent")
        return results


@dataclass
class EmailConfig:
    """Email/SMTP configuration from environment"""

    smtp_server: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_pass: str = ""
    to_email: str = ""

    def __post_init__(self):
        self.smtp_server = os.getenv("SMTP_SERVER", "smtp-mail.outlook.com")
        self.smtp_port = int(os.getenv("SMTP_PORT", "587"))
        self.smtp_user = os.getenv("SMTP_USER", "")
        self.smtp_pass = os.getenv("SMTP_PASS", "")
        self.to_email = os.getenv("ALERT_EMAIL_TO", "")

    def is_configured(self) -> bool:
        """Check if email is properly configured"""
        return bool(
            self.smtp_server and self.smtp_user and self.smtp_pass and self.to_email
        )


class EmailAlertService:
    """Send alerts via Email/SMTP"""

    def __init__(self, config: EmailConfig = None):
        self.config = config or EmailConfig()
        self._initialized = False

    def send_email(self, subject: str, body: str, html_body: str = None) -> bool:
        """
        Send email alert

        Args:
            subject: Email subject
            body: Plain text body
            html_body: Optional HTML body

        Returns:
            True if sent successfully
        """
        if not self.config.is_configured():
            logger.warning("⚠️ Email not configured. Email alerts disabled.")
            logger.info(
                "   Set SMTP_SERVER, SMTP_USER, SMTP_PASS, ALERT_EMAIL_TO in .env"
            )
            return False

        try:
            msg = MIMEMultipart("alternative")
            msg["Subject"] = subject
            msg["From"] = self.config.smtp_user
            msg["To"] = self.config.to_email

            # Add plain text
            msg.attach(MIMEText(body, "plain"))

            # Add HTML if provided
            if html_body:
                msg.attach(MIMEText(html_body, "html"))

            # Connect and send
            with smtplib.SMTP(self.config.smtp_server, self.config.smtp_port) as server:
                server.starttls()
                server.login(self.config.smtp_user, self.config.smtp_pass)
                server.send_message(msg)

            logger.info(f"📧 Email sent to {self.config.to_email}: {subject}")
            return True

        except Exception as e:
            logger.error(f"❌ Failed to send email: {e}")
            return False

    def format_alert_email(self, alert) -> tuple:
        """
        Format alert as email subject and body

        Returns:
            Tuple of (subject, plain_body, html_body)
        """
        type_labels = {
            AlertType.REFUEL: "⛽ Refuel Detected",
            AlertType.THEFT_SUSPECTED: "🚨 FUEL THEFT SUSPECTED",
            AlertType.LOW_FUEL: "🔋 Low Fuel Warning",
            AlertType.SENSOR_OFFLINE: "📵 Sensor Offline",
            AlertType.DRIFT_WARNING: "📉 Drift Warning",
        }

        subject = f"[Fuel Copilot] {type_labels.get(alert.alert_type, 'Alert')} - {alert.truck_id}"

        # Plain text body
        plain_body = f"""
FUEL COPILOT ALERT
==================

Truck: {alert.truck_id}
Type: {alert.alert_type.value.upper()}
Time: {alert.timestamp.strftime('%Y-%m-%d %H:%M:%S UTC')}

{alert.message}
"""
        if alert.details:
            plain_body += "\nDetails:\n"
            for key, value in alert.details.items():
                plain_body += f"  • {key}: {value}\n"

        # HTML body
        priority_colors = {
            AlertPriority.LOW: "#17a2b8",
            AlertPriority.MEDIUM: "#ffc107",
            AlertPriority.HIGH: "#fd7e14",
            AlertPriority.CRITICAL: "#dc3545",
        }
        color = priority_colors.get(alert.priority, "#6c757d")

        details_html = ""
        if alert.details:
            details_html = "<ul>"
            for key, value in alert.details.items():
                details_html += f"<li><strong>{key}:</strong> {value}</li>"
            details_html += "</ul>"

        html_body = f"""
<!DOCTYPE html>
<html>
<head>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 0; padding: 20px; background: #f5f5f5; }}
        .container {{ max-width: 600px; margin: 0 auto; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
        .header {{ background: {color}; color: white; padding: 20px; text-align: center; }}
        .header h1 {{ margin: 0; font-size: 24px; }}
        .content {{ padding: 20px; }}
        .truck-id {{ font-size: 28px; font-weight: bold; color: #333; margin-bottom: 10px; }}
        .timestamp {{ color: #666; font-size: 14px; margin-bottom: 20px; }}
        .message {{ background: #f8f9fa; padding: 15px; border-radius: 4px; margin-bottom: 15px; }}
        .details {{ margin-top: 15px; }}
        .footer {{ background: #f8f9fa; padding: 15px; text-align: center; font-size: 12px; color: #666; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🚛 FUEL COPILOT ALERT</h1>
        </div>
        <div class="content">
            <div class="truck-id">Truck: {alert.truck_id}</div>
            <div class="timestamp">🕐 {alert.timestamp.strftime('%Y-%m-%d %H:%M:%S UTC')}</div>
            <div class="message">{alert.message}</div>
            <div class="details">
                {details_html}
            </div>
        </div>
        <div class="footer">
            Fuel Copilot v3.4.1 | Automated Fleet Monitoring
        </div>
    </div>
</body>
</html>
"""
        return subject, plain_body, html_body


class AlertManager:
    """Central manager for all alert channels"""

    def __init__(self):
        self.twilio = TwilioAlertService()
        self.email = EmailAlertService()  # 🆕 Email service
        self._alert_history: List[Alert] = []
        self._max_history = 1000

        # Rate limiting: prevent spam
        self._last_alert_by_truck: Dict[str, datetime] = {}
        self._min_alert_interval_seconds = (
            3600  # 1 hour between alerts per truck (general)
        )

        # 🔧 v5.11.0: Rate limiting to 1 per 24 hours per alert TYPE + truck
        # EXCEPTION: Refuels are NOT rate limited (detected in real-time)
        self._last_alert_by_type: Dict[str, datetime] = (
            {}
        )  # key = "truck_id:alert_type"
        self._critical_alert_interval_seconds = 86400  # 24 hours for CRITICAL alerts
        self._type_alert_interval_seconds = (
            86400  # 24 hours for same type on same truck
        )

    def _format_alert_message(self, alert: Alert) -> str:
        """Format alert for SMS/WhatsApp"""
        priority_emoji = {
            AlertPriority.LOW: "ℹ️",
            AlertPriority.MEDIUM: "⚠️",
            AlertPriority.HIGH: "🚨",
            AlertPriority.CRITICAL: "🆘",
        }

        type_emoji = {
            AlertType.REFUEL: "⛽",
            AlertType.THEFT_SUSPECTED: "🚨",
            AlertType.THEFT_CONFIRMED: "🆘",  # 🆕
            AlertType.SENSOR_ISSUE: "🔧",  # 🆕
            AlertType.DRIFT_WARNING: "📉",
            AlertType.SENSOR_OFFLINE: "📵",
            AlertType.LOW_FUEL: "🔋",
            AlertType.EFFICIENCY_DROP: "📊",
            AlertType.MAINTENANCE_DUE: "🔧",
            AlertType.DTC_ALERT: "🔧",  # 🆕 v5.7.3
            AlertType.VOLTAGE_ALERT: "🔋",  # 🆕 v5.7.3
            AlertType.IDLE_DEVIATION: "⏱️",  # 🆕 v5.7.6
            AlertType.GPS_QUALITY: "📡",  # 🆕 v5.7.6
            AlertType.MAINTENANCE_PREDICTION: "⚠️",  # 🆕 v5.7.9
        }

        emoji = f"{priority_emoji.get(alert.priority, '📢')} {type_emoji.get(alert.alert_type, '📢')}"
        timestamp = alert.timestamp.strftime("%H:%M")

        msg = f"{emoji} FUEL COPILOT\n"
        msg += f"🚛 Truck: {alert.truck_id}\n"
        msg += f"⏰ {timestamp}\n"
        msg += f"\n{alert.message}"

        if alert.details:
            msg += "\n\nDetails:"
            for key, value in alert.details.items():
                msg += f"\n• {key}: {value}"

        return msg

    def _should_send_alert(self, alert: Alert) -> bool:
        """Check rate limiting and filters"""
        # 🆕 v5.11.0: REFUEL alerts are NEVER rate limited (real-time detection)
        if alert.alert_type == AlertType.REFUEL:
            return True

        # 🔧 v5.11.0: Rate limit all other alerts to 1 per 24 hours per TYPE + truck_id
        type_key = f"{alert.truck_id}:{alert.alert_type.value}"
        last_type_alert = self._last_alert_by_type.get(type_key)

        if last_type_alert:
            elapsed = (utc_now() - last_type_alert).total_seconds()

            # Critical alerts: rate limit to 24 hours
            if alert.priority == AlertPriority.CRITICAL:
                if elapsed < self._critical_alert_interval_seconds:
                    logger.debug(
                        f"Rate limited CRITICAL: {type_key} (last {elapsed:.0f}s ago, need {self._critical_alert_interval_seconds}s = 24h)"
                    )
                    return False
            else:
                # Non-critical: 24 hours per type per truck
                if elapsed < self._type_alert_interval_seconds:
                    logger.debug(
                        f"Rate limited: {type_key} (last {elapsed:.0f}s ago, need 24h)"
                    )
                    return False

        # Also check general per-truck limit (any alert type)
        last_alert = self._last_alert_by_truck.get(alert.truck_id)
        if last_alert:
            elapsed = (utc_now() - last_alert).total_seconds()
            if elapsed < self._min_alert_interval_seconds:
                logger.debug(
                    f"Rate limited (general): {alert.truck_id} (last alert {elapsed:.0f}s ago)"
                )
                return False

        return True

    def send_alert(self, alert: Alert, channels: List[str] = None) -> bool:
        """
        Send alert through configured channels

        Args:
            alert: Alert to send
            channels: List of channels ("sms", "whatsapp", "email"). Uses all if None.

        Returns:
            True if at least one channel succeeded
        """
        # Add to history
        self._alert_history.append(alert)
        if len(self._alert_history) > self._max_history:
            self._alert_history.pop(0)

        # Rate limiting
        if not self._should_send_alert(alert):
            return False

        # Update last alert time (both general and per-type)
        self._last_alert_by_truck[alert.truck_id] = utc_now()
        # 🔧 v5.7.4: Track per alert type to prevent same-type spam
        type_key = f"{alert.truck_id}:{alert.alert_type.value}"
        self._last_alert_by_type[type_key] = utc_now()

        # Default channels based on priority
        if channels is None:
            if alert.priority == AlertPriority.CRITICAL:
                channels = ["sms", "whatsapp", "email"]
            elif alert.priority == AlertPriority.HIGH:
                channels = ["sms", "email"]
            else:
                channels = []  # Low/medium alerts don't send by default

        if not channels:
            logger.info(
                f"Alert logged (no channels): {alert.truck_id} - {alert.alert_type.value}"
            )
            return True

        message = self._format_alert_message(alert)
        success = False

        if "sms" in channels:
            results = self.twilio.broadcast_sms(message)
            if any(results.values()):
                success = True

        if "whatsapp" in channels:
            for number in self.twilio.config.to_numbers:
                if self.twilio.send_whatsapp(number, message):
                    success = True

        # 🆕 Email channel
        if "email" in channels:
            subject, plain_body, html_body = self.email.format_alert_email(alert)
            if self.email.send_email(subject, plain_body, html_body):
                success = True

        return success

    # Convenience methods for common alerts

    def alert_theft_suspected(
        self,
        truck_id: str,
        fuel_drop_gallons: float,
        fuel_drop_pct: float,
        location: str = None,
    ) -> bool:
        """Send theft suspected alert (CRITICAL priority) - SMS + Email"""
        alert = Alert(
            alert_type=AlertType.THEFT_SUSPECTED,
            priority=AlertPriority.CRITICAL,
            truck_id=truck_id,
            message=f"⚠️ POSSIBLE FUEL THEFT DETECTED!\n"
            f"Fuel drop: {fuel_drop_gallons:.1f} gal ({fuel_drop_pct:.1f}%)",
            details={
                "fuel_drop_gallons": f"{fuel_drop_gallons:.1f}",
                "fuel_drop_pct": f"{fuel_drop_pct:.1f}%",
                "location": location or "Unknown",
            },
        )
        return self.send_alert(alert, channels=["sms", "email"])  # 🆕 Added email

    def alert_theft_confirmed(
        self,
        truck_id: str,
        fuel_drop_gallons: float,
        fuel_drop_pct: float,
        time_waited_minutes: float,
        location: str = None,
    ) -> bool:
        """
        🆕 Send CONFIRMED theft alert (fuel drop that didn't recover)
        CRITICAL priority - SMS + Email
        """
        alert = Alert(
            alert_type=AlertType.THEFT_CONFIRMED,
            priority=AlertPriority.CRITICAL,
            truck_id=truck_id,
            message=f"🆘 FUEL THEFT CONFIRMED!\n"
            f"Drop: {fuel_drop_gallons:.1f} gal ({fuel_drop_pct:.1f}%)\n"
            f"Fuel did NOT recover after {time_waited_minutes:.0f} minutes.\n"
            f"ACTION REQUIRED: Investigate immediately!",
            details={
                "fuel_drop_gallons": f"{fuel_drop_gallons:.1f}",
                "fuel_drop_pct": f"{fuel_drop_pct:.1f}%",
                "verification_time": f"{time_waited_minutes:.0f} min",
                "location": location or "Unknown",
                "action": "INVESTIGATE IMMEDIATELY",
            },
        )
        return self.send_alert(alert, channels=["sms", "email"])

    def alert_sensor_issue(
        self,
        truck_id: str,
        drop_pct: float,
        drop_gal: float,
        recovery_info: str = None,
        volatility: float = None,
    ) -> bool:
        """
        🆕 Send sensor issue alert (fuel drop that recovered = sensor glitch)
        MEDIUM priority - Email only (no SMS spam)
        """
        details = {
            "drop_detected": f"{drop_pct:.1f}% ({drop_gal:.1f} gal)",
            "status": "RECOVERED - Likely sensor malfunction",
            "action": "Schedule sensor inspection/calibration",
        }

        if volatility is not None:
            details["sensor_volatility"] = f"{volatility:.1f} (high = unreliable)"

        if recovery_info:
            details["recovery_details"] = recovery_info

        alert = Alert(
            alert_type=AlertType.SENSOR_ISSUE,
            priority=AlertPriority.MEDIUM,
            truck_id=truck_id,
            message=f"🔧 SENSOR ISSUE DETECTED\n"
            f"Fuel dropped {drop_pct:.1f}% but recovered.\n"
            f"This is NOT theft - sensor needs inspection.\n"
            f"Schedule maintenance to check fuel level sensor.",
            details=details,
        )
        # Email only - don't spam SMS for sensor issues
        return self.send_alert(alert, channels=["email"])

    def alert_refuel(
        self,
        truck_id: str,
        gallons_added: float,
        new_level_pct: float,
        location: str = None,
        send_sms: bool = True,
    ) -> bool:
        """
        Send refuel notification - SMS + Email

        Args:
            truck_id: Truck identifier
            gallons_added: Amount of fuel added
            new_level_pct: New fuel level percentage
            location: Optional location string
            send_sms: Whether to send SMS (default True)
        """
        alert = Alert(
            alert_type=AlertType.REFUEL,
            priority=AlertPriority.LOW,
            truck_id=truck_id,
            message=f"⛽ Refuel detected: +{gallons_added:.1f} gallons\n"
            f"New level: {new_level_pct:.1f}%",
            details={
                "gallons_added": f"{gallons_added:.1f}",
                "new_level": f"{new_level_pct:.1f}%",
                "location": location or "Unknown",
            },
        )
        channels = ["sms", "email"] if send_sms else ["email"]  # 🆕 Always send email
        return self.send_alert(alert, channels=channels)

    def alert_low_fuel(
        self,
        truck_id: str,
        current_level_pct: float,
        estimated_miles_remaining: float = None,
        send_sms: bool = False,
    ) -> bool:
        """
        Send low fuel alert with configurable SMS threshold.

        🆕 v3.12.21: Now supports SMS alerts for critical low fuel levels.
        SMS sent when:
        - current_level_pct <= 15% (CRITICAL) - always SMS
        - current_level_pct <= 25% (HIGH) - SMS if send_sms=True

        Args:
            truck_id: Truck identifier
            current_level_pct: Current fuel level percentage
            estimated_miles_remaining: Optional estimated miles
            send_sms: Whether to send SMS for HIGH priority (default False)
        """
        # Determine priority and channels based on fuel level
        if current_level_pct <= 15:
            priority = AlertPriority.CRITICAL
            channels = ["sms", "email"]  # Always SMS for critical
            emoji = "🚨"
        elif current_level_pct <= 25:
            priority = AlertPriority.HIGH
            channels = ["sms", "email"] if send_sms else ["email"]
            emoji = "⚠️"
        else:
            priority = AlertPriority.MEDIUM
            channels = []  # Log only for > 25%
            emoji = "⛽"

        alert = Alert(
            alert_type=AlertType.LOW_FUEL,
            priority=priority,
            truck_id=truck_id,
            message=f"{emoji} LOW FUEL ALERT: {current_level_pct:.1f}%",
            details={
                "current_level": f"{current_level_pct:.1f}%",
                "estimated_miles": (
                    f"{estimated_miles_remaining:.0f}"
                    if estimated_miles_remaining
                    else "N/A"
                ),
                "priority": priority.value,
            },
        )
        return self.send_alert(alert, channels=channels)

    def alert_sensor_offline(self, truck_id: str, offline_minutes: int) -> bool:
        """Send sensor offline alert (MEDIUM priority)"""
        alert = Alert(
            alert_type=AlertType.SENSOR_OFFLINE,
            priority=AlertPriority.MEDIUM,
            truck_id=truck_id,
            message=f"Sensor offline for {offline_minutes} minutes",
            details={"offline_minutes": str(offline_minutes)},
        )
        return self.send_alert(alert, channels=[])  # Log only

    def get_alert_history(
        self, truck_id: str = None, alert_type: AlertType = None, limit: int = 100
    ) -> List[Alert]:
        """Get recent alerts, optionally filtered"""
        alerts = self._alert_history

        if truck_id:
            alerts = [a for a in alerts if a.truck_id == truck_id]

        if alert_type:
            alerts = [a for a in alerts if a.alert_type == alert_type]

        return alerts[-limit:]

    # ═══════════════════════════════════════════════════════════════════════════════
    # 🆕 v5.7.3: DTC AND VOLTAGE ALERTS
    # ═══════════════════════════════════════════════════════════════════════════════

    def alert_dtc(
        self,
        truck_id: str,
        dtc_code: str,
        severity: str,
        description: str,
        system: str = "UNKNOWN",
        recommended_action: Optional[str] = None,
        spn: Optional[int] = None,
        fmi: Optional[int] = None,
        spn_name_es: Optional[str] = None,
        fmi_description_es: Optional[str] = None,
    ) -> bool:
        """
        🆕 v5.8.0: Send DTC (Diagnostic Trouble Code) alert with full Spanish descriptions.

        CRITICAL DTCs → SMS + Email
        WARNING DTCs → Email only

        Now includes comprehensive bilingual information from dtc_database.py v5.8.0:
        - Spanish component name (name_es)
        - Spanish failure description (description_es)
        - Spanish recommended action (action_es)
        - System classification (ENGINE, AFTERTREATMENT, etc.)
        """
        if severity == "CRITICAL":
            priority = AlertPriority.CRITICAL
            channels = ["sms", "email"]
            emoji = "🚨"
            severity_es = "CRÍTICO"
        else:
            priority = AlertPriority.HIGH
            channels = ["email"]
            emoji = "⚠️"
            severity_es = "ADVERTENCIA"

        # Build comprehensive Spanish message
        if spn and fmi and spn_name_es and fmi_description_es:
            # Full Spanish description available from dtc_database
            message = (
                f"{emoji} CÓDIGO DE DIAGNÓSTICO DEL MOTOR\n\n"
                f"🔧 Código: {dtc_code} (SPN {spn} / FMI {fmi})\n"
                f"⚙️ Sistema: {system}\n"
                f"📊 Severidad: {severity_es}\n\n"
                f"🔍 Componente: {spn_name_es}\n"
                f"❌ Falla: {fmi_description_es}\n\n"
                f"✅ Acción Recomendada:\n{recommended_action or 'Revisar inmediatamente con técnico especializado'}"
            )
        else:
            # Fallback to basic description
            message = (
                f"{emoji} CÓDIGO DE DIAGNÓSTICO DEL MOTOR\n\n"
                f"🔧 Código: {dtc_code}\n"
                f"⚙️ Sistema: {system}\n"
                f"📊 Severidad: {severity_es}\n\n"
                f"❌ Descripción: {description}\n\n"
                f"✅ Acción Recomendada:\n{recommended_action or 'Programar inspección de servicio'}"
            )

        alert = Alert(
            alert_type=AlertType.DTC_ALERT,
            priority=priority,
            truck_id=truck_id,
            message=message,
            details={
                "dtc_code": dtc_code,
                "spn": spn,
                "fmi": fmi,
                "severity": severity,
                "severity_es": severity_es,
                "system": system,
                "description": description,
                "spn_name_es": spn_name_es,
                "fmi_description_es": fmi_description_es,
                "action": recommended_action or "Programar inspección de servicio",
            },
        )
        return self.send_alert(alert, channels=channels)

    def alert_voltage(
        self,
        truck_id: str,
        voltage: float,
        priority_level: str,
        message: str,
        is_engine_running: bool = False,
    ) -> bool:
        """
        🆕 v5.7.3: Send voltage alert for battery/alternator issues.

        CRITICAL → SMS + Email (alternator failure likely)
        WARNING → Email only
        """
        if priority_level == "CRITICAL":
            priority = AlertPriority.CRITICAL
            channels = ["sms", "email"]
            emoji = "🔋🚨"
        else:
            priority = AlertPriority.HIGH
            channels = ["email"]
            emoji = "🔋⚠️"

        alert = Alert(
            alert_type=AlertType.VOLTAGE_ALERT,
            priority=priority,
            truck_id=truck_id,
            message=f"{emoji} VOLTAGE ALERT\n{message}",
            details={
                "voltage": f"{voltage:.1f}V",
                "engine_status": "Running" if is_engine_running else "Off",
                "priority": priority_level,
                "action": (
                    "Check battery/alternator immediately"
                    if priority_level == "CRITICAL"
                    else "Monitor and schedule check"
                ),
            },
        )
        return self.send_alert(alert, channels=channels)

    # ═══════════════════════════════════════════════════════════════════════════════
    # 🆕 v5.7.6: IDLE DEVIATION AND GPS QUALITY ALERTS
    # ═══════════════════════════════════════════════════════════════════════════════

    def alert_idle_deviation(
        self,
        truck_id: str,
        calculated_hours: float,
        ecu_hours: float,
        deviation_pct: float,
    ) -> bool:
        """
        🆕 v5.7.6: Send alert when idle calculation differs significantly from ECU.

        Deviation > 25% → HIGH priority (possible sensor miscalibration)
        Deviation > 15% → MEDIUM priority (investigate)
        """
        if abs(deviation_pct) > 25:
            priority = AlertPriority.HIGH
            channels = ["email"]
            emoji = "⏱️🚨"
            message = f"SIGNIFICANT IDLE DEVIATION DETECTED\n"
        else:
            priority = AlertPriority.MEDIUM
            channels = ["email"]
            emoji = "⏱️⚠️"
            message = f"IDLE TRACKING DEVIATION\n"

        message += (
            f"Our calculation: {calculated_hours:.1f}h\n"
            f"ECU reported: {ecu_hours:.1f}h\n"
            f"Deviation: {deviation_pct:+.1f}%"
        )

        alert = Alert(
            alert_type=AlertType.IDLE_DEVIATION,
            priority=priority,
            truck_id=truck_id,
            message=f"{emoji} {message}",
            details={
                "calculated_idle_hours": f"{calculated_hours:.1f}h",
                "ecu_idle_hours": f"{ecu_hours:.1f}h",
                "deviation_pct": f"{deviation_pct:+.1f}%",
                "action": (
                    "Schedule sensor recalibration"
                    if abs(deviation_pct) > 25
                    else "Monitor for next 24 hours"
                ),
            },
        )
        return self.send_alert(alert, channels=channels)

    def alert_maintenance_prediction(
        self,
        truck_id: str,
        sensor: str,
        current_value: float,
        threshold: float,
        days_to_failure: float,
        urgency: str,
        unit: str = "",
    ) -> bool:
        """
        🆕 v5.7.9: Send predictive maintenance alert for days-to-failure < 7.

        Alerts when a sensor is trending toward failure threshold.

        Args:
            truck_id: Truck identifier
            sensor: Sensor name (e.g., "battery_voltage", "coolant_temp_f")
            current_value: Current sensor value
            threshold: Threshold value being approached
            days_to_failure: Estimated days until threshold is crossed
            urgency: CRITICAL, HIGH, or MEDIUM
            unit: Unit of measurement (e.g., "V", "°F", "PSI")

        Returns:
            True if alert sent successfully
        """
        # Determine priority based on urgency
        if urgency == "CRITICAL" or days_to_failure < 3:
            priority = AlertPriority.CRITICAL
            channels = ["sms", "email"]
            emoji = "🚨⚠️"
            message = "URGENT: MAINTENANCE NEEDED SOON"
        elif urgency == "HIGH" or days_to_failure < 5:
            priority = AlertPriority.HIGH
            channels = ["email"]
            emoji = "⚠️🔧"
            message = "MAINTENANCE ALERT"
        else:
            priority = AlertPriority.MEDIUM
            channels = ["email"]
            emoji = "📊🔧"
            message = "MAINTENANCE PREDICTION"

        # Format sensor name for display
        sensor_display = sensor.replace("_", " ").title()

        alert = Alert(
            alert_type=AlertType.MAINTENANCE_PREDICTION,
            priority=priority,
            truck_id=truck_id,
            message=f"{emoji} {message}\n"
            f"Sensor: {sensor_display}\n"
            f"Current: {current_value:.1f}{unit}\n"
            f"Threshold: {threshold:.1f}{unit}\n"
            f"Days to failure: ~{days_to_failure:.0f} days",
            details={
                "sensor": sensor,
                "current_value": f"{current_value:.1f}{unit}",
                "threshold": f"{threshold:.1f}{unit}",
                "days_to_failure": f"{days_to_failure:.0f} days",
                "urgency": urgency,
                "action": (
                    "Schedule immediate maintenance"
                    if days_to_failure < 3
                    else f"Schedule maintenance within {int(days_to_failure)} days"
                ),
            },
        )
        return self.send_alert(alert, channels=channels)

    def alert_gps_quality(
        self,
        truck_id: str,
        satellites: int,
        quality_level: str,
        estimated_accuracy_m: float = None,
    ) -> bool:
        """
        🆕 v5.7.6: Send alert for poor GPS signal quality.

        CRITICAL (<4 sats) → HIGH priority
        POOR (4-6 sats) → MEDIUM priority
        """
        if quality_level == "CRITICAL" or satellites < 4:
            priority = AlertPriority.HIGH
            channels = ["email"]
            emoji = "📡🚨"
            message = "GPS SIGNAL CRITICAL"
        else:
            priority = AlertPriority.MEDIUM
            channels = ["email"]
            emoji = "📡⚠️"
            message = "GPS SIGNAL DEGRADED"

        alert = Alert(
            alert_type=AlertType.GPS_QUALITY,
            priority=priority,
            truck_id=truck_id,
            message=f"{emoji} {message}\n"
            f"Satellites: {satellites}\n"
            f"Quality: {quality_level}"
            + (
                f"\nAccuracy: ~{estimated_accuracy_m:.0f}m"
                if estimated_accuracy_m
                else ""
            ),
            details={
                "satellites": satellites,
                "quality": quality_level,
                "accuracy_m": (
                    f"{estimated_accuracy_m:.0f}" if estimated_accuracy_m else "N/A"
                ),
                "action": "Check GPS antenna connection and placement",
            },
        )
        return self.send_alert(alert, channels=channels)


# Global instance for easy access
_alert_manager: AlertManager = None


def get_alert_manager() -> AlertManager:
    """Get global AlertManager instance"""
    global _alert_manager
    if _alert_manager is None:
        _alert_manager = AlertManager()
    return _alert_manager


# Convenience functions
def send_theft_alert(
    truck_id: str, fuel_drop_gallons: float, fuel_drop_pct: float, location: str = None
) -> bool:
    """Quick function to send theft SUSPECTED alert"""
    return get_alert_manager().alert_theft_suspected(
        truck_id, fuel_drop_gallons, fuel_drop_pct, location
    )


def send_theft_confirmed_alert(
    truck_id: str,
    fuel_drop_gallons: float,
    fuel_drop_pct: float,
    time_waited_minutes: float,
    location: str = None,
) -> bool:
    """🆕 Quick function to send CONFIRMED theft alert (drop didn't recover)"""
    return get_alert_manager().alert_theft_confirmed(
        truck_id, fuel_drop_gallons, fuel_drop_pct, time_waited_minutes, location
    )


def send_sensor_issue_alert(
    truck_id: str,
    drop_pct: float,
    drop_gal: float,
    recovery_info: str = None,
    volatility: float = None,
) -> bool:
    """🆕 Quick function to send sensor issue alert (drop recovered = sensor glitch)"""
    return get_alert_manager().alert_sensor_issue(
        truck_id, drop_pct, drop_gal, recovery_info, volatility
    )


def send_low_fuel_alert(
    truck_id: str,
    current_level_pct: float,
    estimated_miles: float = None,
    send_sms: bool = False,
) -> bool:
    """
    Quick function to send low fuel alert.

    🆕 v3.12.21: SMS automatically sent for critical levels (≤15%).
    For HIGH levels (≤25%), set send_sms=True to also receive SMS.
    """
    return get_alert_manager().alert_low_fuel(
        truck_id, current_level_pct, estimated_miles, send_sms
    )


def send_dtc_alert(
    truck_id: str,
    dtc_code: str,
    severity: str,
    description: str,
    system: str = "UNKNOWN",
    recommended_action: Optional[str] = None,
    spn: Optional[int] = None,
    fmi: Optional[int] = None,
    spn_name_es: Optional[str] = None,
    fmi_description_es: Optional[str] = None,
) -> bool:
    """🆕 v5.8.0: Quick function to send DTC alert with full Spanish descriptions"""
    return get_alert_manager().alert_dtc(
        truck_id,
        dtc_code,
        severity,
        description,
        system,
        recommended_action,
        spn,
        fmi,
        spn_name_es,
        fmi_description_es,
    )


def send_voltage_alert(
    truck_id: str,
    voltage: float,
    priority_level: str,
    message: str,
    is_engine_running: bool = False,
) -> bool:
    """🆕 v5.7.3: Quick function to send voltage alert"""
    return get_alert_manager().alert_voltage(
        truck_id, voltage, priority_level, message, is_engine_running
    )


def send_idle_deviation_alert(
    truck_id: str,
    calculated_hours: float,
    ecu_hours: float,
    deviation_pct: float,
) -> bool:
    """🆕 v5.7.6: Quick function to send idle deviation alert"""
    return get_alert_manager().alert_idle_deviation(
        truck_id, calculated_hours, ecu_hours, deviation_pct
    )


def send_gps_quality_alert(
    truck_id: str,
    satellites: int,
    quality_level: str,
    estimated_accuracy_m: float = None,
) -> bool:
    """🆕 v5.7.6: Quick function to send GPS quality alert"""
    return get_alert_manager().alert_gps_quality(
        truck_id, satellites, quality_level, estimated_accuracy_m
    )


def send_maintenance_prediction_alert(
    truck_id: str,
    sensor: str,
    current_value: float,
    threshold: float,
    days_to_failure: float,
    urgency: str,
    unit: str = "",
) -> bool:
    """🆕 v5.7.9: Quick function to send predictive maintenance alert"""
    return get_alert_manager().alert_maintenance_prediction(
        truck_id, sensor, current_value, threshold, days_to_failure, urgency, unit
    )


if __name__ == "__main__":
    # Test the alert service
    logging.basicConfig(level=logging.INFO)

    print("🧪 Testing Alert Service")
    print("=" * 50)

    manager = get_alert_manager()

    # Check configuration
    print(f"\nTwilio configured: {manager.twilio.config.is_configured()}")
    print(
        f"Account SID: {manager.twilio.config.account_sid[:10]}..."
        if manager.twilio.config.account_sid
        else "Not set"
    )
    print(f"From number: {manager.twilio.config.from_number or 'Not set'}")
    print(f"To numbers: {manager.twilio.config.to_numbers or 'Not set'}")

    # Test alert (won't actually send if not configured)
    print("\n📱 Testing theft alert...")
    result = manager.alert_theft_suspected(
        truck_id="TEST123",
        fuel_drop_gallons=50.5,
        fuel_drop_pct=15.2,
        location="Houston, TX",
    )
    print(f"Alert sent: {result}")

    # Show history
    print(f"\n📋 Alert history: {len(manager._alert_history)} alerts")
