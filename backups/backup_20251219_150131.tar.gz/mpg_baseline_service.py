"""
MPG Baseline Service v5.7.6
═══════════════════════════════════════════════════════════════════════════════

Historical MPG Baseline Calculator
Calculates per-truck MPG baselines from historical fuel_metrics data.

Features:
- Calculate baseline from last N days of data
- Use IQR outlier filtering for clean data
- Store baselines in database for persistence
- Compare current readings against learned baseline

Usage:
    service = MPGBaselineService(db_pool)

    # Calculate baseline for one truck (last 30 days)
    baseline = await service.calculate_baseline("CO0681", days=30)

    # Calculate baselines for entire fleet
    fleet_baselines = await service.calculate_fleet_baselines(days=30)

    # Get deviation analysis
    deviation = service.analyze_deviation("CO0681", current_mpg=4.2)

Author: Fuel Analytics Team
Version: 5.7.6
"""

import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Optional
import statistics

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════════
# DATA CLASSES
# ═══════════════════════════════════════════════════════════════════════════════


@dataclass
class MPGBaseline:
    """Historical MPG baseline for a truck"""

    truck_id: str
    baseline_mpg: float = 5.7  # Fleet average default
    std_dev: float = 0.8  # Default uncertainty
    min_mpg: float = 3.0
    max_mpg: float = 9.0
    sample_count: int = 0
    days_analyzed: int = 0
    confidence: str = "LOW"  # LOW, MEDIUM, HIGH, VERY_HIGH
    last_calculated: Optional[datetime] = None
    percentile_25: float = 5.0
    percentile_75: float = 6.5

    @property
    def confidence_score(self) -> float:
        """Numeric confidence score 0-1"""
        if self.sample_count >= 100:
            return 1.0
        elif self.sample_count >= 50:
            return 0.75
        elif self.sample_count >= 20:
            return 0.5
        elif self.sample_count >= 10:
            return 0.25
        return 0.0

    def to_dict(self) -> dict:
        """Serialize for API response"""
        return {
            "truck_id": self.truck_id,
            "baseline_mpg": round(self.baseline_mpg, 2),
            "std_dev": round(self.std_dev, 2),
            "min_mpg": round(self.min_mpg, 2),
            "max_mpg": round(self.max_mpg, 2),
            "sample_count": self.sample_count,
            "days_analyzed": self.days_analyzed,
            "confidence": self.confidence,
            "confidence_score": self.confidence_score,
            "percentile_25": round(self.percentile_25, 2),
            "percentile_75": round(self.percentile_75, 2),
            "last_calculated": (
                self.last_calculated.isoformat() if self.last_calculated else None
            ),
        }


@dataclass
class DeviationAnalysis:
    """Analysis of current MPG vs baseline"""

    truck_id: str
    current_mpg: float
    baseline_mpg: float
    deviation_pct: float
    z_score: float
    status: str  # NORMAL, LOW, HIGH, CRITICAL_LOW, CRITICAL_HIGH
    message: str
    confidence: str

    def to_dict(self) -> dict:
        return {
            "truck_id": self.truck_id,
            "current_mpg": round(self.current_mpg, 2),
            "baseline_mpg": round(self.baseline_mpg, 2),
            "deviation_pct": round(self.deviation_pct, 1),
            "z_score": round(self.z_score, 2),
            "status": self.status,
            "message": self.message,
            "confidence": self.confidence,
        }


# ═══════════════════════════════════════════════════════════════════════════════
# UTILITY FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════


def filter_outliers_iqr(data: list[float], multiplier: float = 1.5) -> list[float]:
    """
    Remove outliers using Interquartile Range method.

    Args:
        data: List of values
        multiplier: IQR multiplier (1.5 = standard, 3.0 = extreme only)

    Returns:
        Filtered list without outliers
    """
    if len(data) < 4:
        return data

    sorted_data = sorted(data)
    n = len(sorted_data)

    q1_idx = n // 4
    q3_idx = (3 * n) // 4

    q1 = sorted_data[q1_idx]
    q3 = sorted_data[q3_idx]
    iqr = q3 - q1

    lower_bound = q1 - (multiplier * iqr)
    upper_bound = q3 + (multiplier * iqr)

    return [x for x in data if lower_bound <= x <= upper_bound]


def calculate_percentile(data: list[float], percentile: int) -> float:
    """Calculate percentile of data"""
    if not data:
        return 0.0
    sorted_data = sorted(data)
    idx = int(len(sorted_data) * percentile / 100)
    return sorted_data[min(idx, len(sorted_data) - 1)]


def get_confidence_level(sample_count: int, days: int) -> str:
    """
    Determine confidence level based on sample count and time span.

    Args:
        sample_count: Number of valid readings
        days: Days of data analyzed

    Returns:
        Confidence level string
    """
    # Need minimum readings per day
    if days == 0:
        return "LOW"

    readings_per_day = sample_count / days

    if sample_count >= 200 and readings_per_day >= 10:
        return "VERY_HIGH"
    elif sample_count >= 100 and readings_per_day >= 5:
        return "HIGH"
    elif sample_count >= 50 and readings_per_day >= 3:
        return "MEDIUM"
    elif sample_count >= 20:
        return "LOW"
    return "INSUFFICIENT"


# ═══════════════════════════════════════════════════════════════════════════════
# BASELINE SERVICE
# ═══════════════════════════════════════════════════════════════════════════════


class MPGBaselineService:
    """
    Service for calculating and managing historical MPG baselines.

    Calculates per-truck baselines from fuel_metrics table using:
    - IQR filtering to remove outliers
    - Statistical analysis (mean, std, percentiles)
    - Confidence scoring based on data quality
    """

    # Valid MPG range for Class 8 trucks
    MIN_VALID_MPG = 3.0
    MAX_VALID_MPG = 12.0

    # Minimum samples required for baseline
    MIN_SAMPLES = 10

    def __init__(self, db_pool=None):
        """
        Initialize service.

        Args:
            db_pool: Database connection pool (aiomysql)
        """
        self.db_pool = db_pool
        self._baselines_cache: dict[str, MPGBaseline] = {}

    async def calculate_baseline(
        self, truck_id: str, days: int = 30, min_speed_mph: float = 10.0
    ) -> MPGBaseline:
        """
        Calculate historical baseline for a single truck.

        Args:
            truck_id: Truck identifier
            days: Number of days to analyze (default 30)
            min_speed_mph: Minimum speed to filter (exclude idle)

        Returns:
            MPGBaseline object with calculated values
        """
        if not self.db_pool:
            logger.warning(f"[{truck_id}] No database pool, returning default baseline")
            return MPGBaseline(truck_id=truck_id)

        try:
            async with self.db_pool.acquire() as conn:
                async with conn.cursor() as cursor:
                    # Query historical MPG data
                    query = """
                        SELECT mpg_current, timestamp_utc
                        FROM fuel_metrics
                        WHERE truck_id = %s
                          AND timestamp_utc >= DATE_SUB(NOW(), INTERVAL %s DAY)
                          AND mpg_current BETWEEN %s AND %s
                          AND speed_mph >= %s
                        ORDER BY timestamp_utc DESC
                        LIMIT 5000
                    """

                    await cursor.execute(
                        query,
                        (
                            truck_id,
                            days,
                            self.MIN_VALID_MPG,
                            self.MAX_VALID_MPG,
                            min_speed_mph,
                        ),
                    )

                    rows = await cursor.fetchall()

            return self._calculate_from_readings(truck_id, rows, days)

        except Exception as e:
            logger.error(f"[{truck_id}] Error calculating baseline: {e}")
            return MPGBaseline(truck_id=truck_id)

    def _calculate_from_readings(
        self, truck_id: str, rows: list, days: int
    ) -> MPGBaseline:
        """
        Calculate baseline from database readings.

        Args:
            truck_id: Truck identifier
            rows: List of (mpg_current, timestamp_utc) tuples
            days: Days analyzed

        Returns:
            Calculated MPGBaseline
        """
        baseline = MPGBaseline(
            truck_id=truck_id, days_analyzed=days, last_calculated=datetime.utcnow()
        )

        if not rows or len(rows) < self.MIN_SAMPLES:
            logger.info(
                f"[{truck_id}] Insufficient data: {len(rows) if rows else 0} samples"
            )
            baseline.confidence = "INSUFFICIENT"
            return baseline

        # Extract MPG values
        mpg_values = [float(row[0]) for row in rows if row[0] is not None]

        if len(mpg_values) < self.MIN_SAMPLES:
            baseline.confidence = "INSUFFICIENT"
            return baseline

        # Filter outliers using IQR
        filtered_values = filter_outliers_iqr(mpg_values, multiplier=1.5)

        if len(filtered_values) < 5:
            # Too aggressive filtering, use original
            filtered_values = mpg_values

        # Calculate statistics
        baseline.sample_count = len(filtered_values)
        baseline.baseline_mpg = statistics.mean(filtered_values)
        baseline.std_dev = (
            statistics.stdev(filtered_values) if len(filtered_values) > 1 else 0.8
        )
        baseline.min_mpg = min(filtered_values)
        baseline.max_mpg = max(filtered_values)
        baseline.percentile_25 = calculate_percentile(filtered_values, 25)
        baseline.percentile_75 = calculate_percentile(filtered_values, 75)
        baseline.confidence = get_confidence_level(baseline.sample_count, days)

        # Cache result
        self._baselines_cache[truck_id] = baseline

        logger.info(
            f"[{truck_id}] Baseline calculated: {baseline.baseline_mpg:.2f} MPG "
            f"(σ={baseline.std_dev:.2f}, n={baseline.sample_count}, conf={baseline.confidence})"
        )

        return baseline

    async def calculate_fleet_baselines(
        self, days: int = 30, min_speed_mph: float = 10.0
    ) -> dict[str, MPGBaseline]:
        """
        Calculate baselines for all trucks in fleet.

        Args:
            days: Number of days to analyze
            min_speed_mph: Minimum speed filter

        Returns:
            Dict mapping truck_id to MPGBaseline
        """
        if not self.db_pool:
            logger.warning("No database pool, returning empty baselines")
            return {}

        try:
            async with self.db_pool.acquire() as conn:
                async with conn.cursor() as cursor:
                    # Get all active trucks
                    query = """
                        SELECT DISTINCT truck_id
                        FROM fuel_metrics
                        WHERE timestamp_utc >= DATE_SUB(NOW(), INTERVAL %s DAY)
                    """
                    await cursor.execute(query, (days,))
                    trucks = await cursor.fetchall()

            baselines = {}
            for (truck_id,) in trucks:
                baseline = await self.calculate_baseline(
                    truck_id, days=days, min_speed_mph=min_speed_mph
                )
                baselines[truck_id] = baseline

            logger.info(f"Calculated baselines for {len(baselines)} trucks")
            return baselines

        except Exception as e:
            logger.error(f"Error calculating fleet baselines: {e}")
            return {}

    def analyze_deviation(
        self, truck_id: str, current_mpg: float, baseline: Optional[MPGBaseline] = None
    ) -> DeviationAnalysis:
        """
        Analyze how current MPG deviates from baseline.

        Args:
            truck_id: Truck identifier
            current_mpg: Current MPG reading
            baseline: Optional pre-calculated baseline (uses cache if not provided)

        Returns:
            DeviationAnalysis with status and recommendations
        """
        # Get baseline from cache or use default
        if baseline is None:
            baseline = self._baselines_cache.get(
                truck_id, MPGBaseline(truck_id=truck_id)
            )

        # Calculate deviation
        if baseline.baseline_mpg > 0:
            deviation_pct = (
                (current_mpg - baseline.baseline_mpg) / baseline.baseline_mpg
            ) * 100
        else:
            deviation_pct = 0.0

        # Calculate z-score
        if baseline.std_dev > 0:
            z_score = (current_mpg - baseline.baseline_mpg) / baseline.std_dev
        else:
            z_score = 0.0

        # Determine status
        status, message = self._get_deviation_status(
            z_score, deviation_pct, current_mpg
        )

        return DeviationAnalysis(
            truck_id=truck_id,
            current_mpg=current_mpg,
            baseline_mpg=baseline.baseline_mpg,
            deviation_pct=deviation_pct,
            z_score=z_score,
            status=status,
            message=message,
            confidence=baseline.confidence,
        )

    def _get_deviation_status(
        self, z_score: float, deviation_pct: float, current_mpg: float
    ) -> tuple[str, str]:
        """
        Determine status and message based on deviation.

        Args:
            z_score: Standard deviations from mean
            deviation_pct: Percentage deviation
            current_mpg: Current reading

        Returns:
            Tuple of (status, message)
        """
        # Critical thresholds
        if z_score < -3.0 or current_mpg < 3.5:
            return (
                "CRITICAL_LOW",
                f"MPG muy bajo ({current_mpg:.1f}) - revisar motor/sensores inmediatamente",
            )

        if z_score > 3.0 or current_mpg > 10.0:
            return (
                "CRITICAL_HIGH",
                f"MPG anormalmente alto ({current_mpg:.1f}) - posible error de sensor",
            )

        # Anomaly thresholds
        if z_score < -2.0:
            return (
                "LOW",
                f"MPG bajo ({deviation_pct:.0f}% debajo del baseline) - monitorear",
            )

        if z_score > 2.0:
            return (
                "HIGH",
                f"MPG alto ({deviation_pct:+.0f}% arriba del baseline) - verificar sensor",
            )

        # Minor deviation
        if abs(z_score) > 1.0:
            direction = "bajo" if z_score < 0 else "alto"
            return "NOTABLE", f"Desviación menor ({direction}, {deviation_pct:+.0f}%)"

        # Normal range
        return "NORMAL", "Dentro del rango normal para este truck"

    def get_fleet_summary(self) -> dict:
        """
        Get summary statistics for cached baselines.

        Returns:
            Summary dict with fleet-wide statistics
        """
        if not self._baselines_cache:
            return {
                "total_trucks": 0,
                "avg_baseline_mpg": 5.7,
                "trucks_high_confidence": 0,
                "trucks_low_confidence": 0,
            }

        baselines = list(self._baselines_cache.values())

        high_confidence = [
            b for b in baselines if b.confidence in ("HIGH", "VERY_HIGH")
        ]
        low_confidence = [
            b for b in baselines if b.confidence in ("LOW", "INSUFFICIENT")
        ]

        avg_mpg = (
            statistics.mean([b.baseline_mpg for b in baselines]) if baselines else 5.7
        )

        return {
            "total_trucks": len(baselines),
            "avg_baseline_mpg": round(avg_mpg, 2),
            "trucks_high_confidence": len(high_confidence),
            "trucks_low_confidence": len(low_confidence),
            "baselines": [
                b.to_dict() for b in sorted(baselines, key=lambda x: x.truck_id)
            ],
        }


# ═══════════════════════════════════════════════════════════════════════════════
# STANDALONE CALCULATION (No DB required)
# ═══════════════════════════════════════════════════════════════════════════════


def calculate_baseline_from_list(
    truck_id: str, mpg_readings: list[float], days: int = 30
) -> MPGBaseline:
    """
    Calculate baseline from a list of MPG readings (no DB required).

    Useful for testing or when data is already loaded.

    Args:
        truck_id: Truck identifier
        mpg_readings: List of MPG values
        days: Days of data (for confidence calculation)

    Returns:
        Calculated MPGBaseline
    """
    baseline = MPGBaseline(
        truck_id=truck_id, days_analyzed=days, last_calculated=datetime.utcnow()
    )

    # Filter to valid range
    valid_readings = [mpg for mpg in mpg_readings if 3.0 <= mpg <= 12.0]

    if len(valid_readings) < 10:
        baseline.confidence = "INSUFFICIENT"
        return baseline

    # Filter outliers
    filtered = filter_outliers_iqr(valid_readings, multiplier=1.5)

    if len(filtered) < 5:
        filtered = valid_readings

    # Calculate statistics
    baseline.sample_count = len(filtered)
    baseline.baseline_mpg = statistics.mean(filtered)
    baseline.std_dev = statistics.stdev(filtered) if len(filtered) > 1 else 0.8
    baseline.min_mpg = min(filtered)
    baseline.max_mpg = max(filtered)
    baseline.percentile_25 = calculate_percentile(filtered, 25)
    baseline.percentile_75 = calculate_percentile(filtered, 75)
    baseline.confidence = get_confidence_level(baseline.sample_count, days)

    return baseline


def compare_to_fleet_average(
    truck_baseline: MPGBaseline, fleet_average: float = 5.7
) -> dict:
    """
    Compare truck baseline to fleet average.

    Args:
        truck_baseline: Truck's calculated baseline
        fleet_average: Fleet-wide average (default 5.7 MPG)

    Returns:
        Comparison dict
    """
    diff = truck_baseline.baseline_mpg - fleet_average
    diff_pct = (diff / fleet_average) * 100 if fleet_average > 0 else 0

    if diff_pct > 10:
        status = "ABOVE_AVERAGE"
        message = f"Truck performs {diff_pct:.0f}% better than fleet average"
    elif diff_pct < -10:
        status = "BELOW_AVERAGE"
        message = f"Truck performs {abs(diff_pct):.0f}% worse than fleet average"
    else:
        status = "AVERAGE"
        message = "Truck performs at fleet average"

    return {
        "truck_id": truck_baseline.truck_id,
        "truck_baseline": round(truck_baseline.baseline_mpg, 2),
        "fleet_average": fleet_average,
        "difference_mpg": round(diff, 2),
        "difference_pct": round(diff_pct, 1),
        "status": status,
        "message": message,
    }
